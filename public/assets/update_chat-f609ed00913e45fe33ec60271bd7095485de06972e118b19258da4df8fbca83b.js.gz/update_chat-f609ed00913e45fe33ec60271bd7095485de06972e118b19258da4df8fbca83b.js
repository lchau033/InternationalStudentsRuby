/**
 * Created by liach on 2017-03-25.
 */

$(window).load(function() {
    var open = gon.open;
    if(open){
        document.getElementById("bubble").click();
    }
});
